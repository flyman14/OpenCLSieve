Shakeel Noorali A00770863
Nick Taylor A00824983

This program implements a Sieve of Eratosthenes. It counts the number of prime numbers between 1 and 100.